#!/usr/bin/env bash
set -euo pipefail
mkdir -p backups
cp -f Caddyfile "backups/Caddyfile_$(date +%Y%m%d_%H%M%S)"
echo "✅ 已备份配置"
