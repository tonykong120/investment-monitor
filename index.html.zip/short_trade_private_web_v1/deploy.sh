#!/usr/bin/env bash
set -euo pipefail

echo "======================================"
echo "  短线狙击工作台 · 私密公网部署"
echo "======================================"
echo

if ! command -v docker >/dev/null 2>&1; then
  echo "❌ 未检测到 Docker。"
  echo "请先安装 Docker Engine + Docker Compose 插件，然后重新运行本脚本。"
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "❌ 未检测到 docker compose。"
  exit 1
fi

read -rp "请输入工作台域名（例如 trade.example.com）: " DOMAIN
read -rp "请输入登录用户名（默认 trader）: " USERNAME
USERNAME="${USERNAME:-trader}"

echo
echo "请输入登录密码（输入时不会显示）:"
read -rsp "密码: " PASSWORD
echo
read -rsp "再输入一次: " PASSWORD2
echo

if [[ "$PASSWORD" != "$PASSWORD2" ]]; then
  echo "❌ 两次密码不一致。"
  exit 1
fi
if [[ ${#PASSWORD} -lt 10 ]]; then
  echo "❌ 密码至少 10 位。"
  exit 1
fi

echo "🔐 正在生成 Argon2id 密码哈希…"
HASH="$(printf '%s' "$PASSWORD" | docker run --rm -i caddy:2 caddy hash-password --algorithm argon2id)"

python3 - "$DOMAIN" "$USERNAME" "$HASH" <<'PY'
from pathlib import Path
import sys
domain, username, h = sys.argv[1], sys.argv[2], sys.argv[3]
t = Path("Caddyfile.template").read_text(encoding="utf-8")
t = t.replace("DOMAIN_PLACEHOLDER", domain)
t = t.replace("USER_PLACEHOLDER", username)
t = t.replace("HASH_PLACEHOLDER", h)
Path("Caddyfile").write_text(t, encoding="utf-8")
PY

unset PASSWORD PASSWORD2 HASH

echo "🧱 构建并启动…"
docker compose up -d --build

echo
echo "✅ 已启动。"
echo "网址：https://${DOMAIN}"
echo
echo "如果暂时打不开，请确认："
echo "1) 域名 A 记录已指向本服务器公网 IP"
echo "2) 云防火墙/安全组已放行 TCP 80、443"
echo "3) 服务器本机防火墙已放行 80、443"
echo
echo "查看日志：docker compose logs -f"
