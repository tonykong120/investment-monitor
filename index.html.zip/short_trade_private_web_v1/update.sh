#!/usr/bin/env bash
set -euo pipefail
docker compose up -d --build
docker image prune -f
echo "✅ 更新完成"
