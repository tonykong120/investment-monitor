# 短线狙击工作台 V1｜私密公网版

## 你最终会得到
`https://你的域名`

访问时浏览器先要求输入用户名和密码；没有账号密码无法进入。
工作台本体只在 Docker 内网暴露 8501，不直接对公网开放。

## 安全设计
- Caddy 自动 HTTPS
- Argon2id 哈希密码
- HTTP Basic Auth
- X-Robots-Tag: noindex, nofollow, noarchive
- App 端口不映射到宿主机公网
- Caddy 仅暴露 80/443
- 密码明文不会写入项目文件

> 说明：任何联网系统都不能承诺“绝对没人能看到”。本方案的含义是：
> 未通过登录鉴权的普通访问者无法看到工作台内容。

## 部署前只需要
1. 一台有公网 IP 的 Linux 云服务器（Ubuntu/Debian 均可）
2. 一个域名或子域名，例如 `trade.example.com`
3. 域名 A 记录指向服务器公网 IP
4. 云安全组放行 TCP 80、443
5. Docker Engine + Docker Compose V2

## 一键部署
上传整个文件夹到服务器后：

```bash
cd short_trade_private_web_v1
chmod +x deploy.sh
./deploy.sh
```

脚本会询问：
- 域名
- 登录用户名
- 登录密码

然后自动：
- 生成 Argon2id 密码哈希
- 生成 Caddyfile
- 构建工作台
- 启动 Caddy
- 自动申请 HTTPS 证书

## 管理命令
状态：
```bash
docker compose ps
```

日志：
```bash
docker compose logs -f
```

重启：
```bash
docker compose restart
```

停止：
```bash
docker compose down
```

更新代码后：
```bash
./update.sh
```

## 数据
V1 使用 AKShare 获取公开 A 股行情、日 K、个股资金流。
Level-2 / 十档盘口 / 逐笔成交尚未接入。

## 重要
V1 的资金流是数据商算法指标，不是交易所对真实机构身份的确认。
短线候选是筛选结果，不代表收益承诺。
