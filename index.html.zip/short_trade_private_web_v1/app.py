
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

st.set_page_config(page_title="短线狙击工作台", page_icon="🎯", layout="wide")

try:
    import akshare as ak
except Exception:
    ak = None

DEFAULT = {
    "min_price": 5.0,
    "max_price": 30.0,
    "min_turnover_yi": 5.0,
    "min_turnover_rate": 1.0,
    "max_day_pct": 5.0,
    "max_candidates": 35,
    "stop_loss_pct": 2.5,
    "take_profit1_pct": 3.0,
    "take_profit2_pct": 5.0,
}

def allowed(code, name):
    code = str(code).zfill(6)
    if code.startswith(("688", "300", "301", "8", "4")):
        return False
    return ("ST" not in str(name)) and ("退" not in str(name))

def n(s):
    return pd.to_numeric(s, errors="coerce")

@st.cache_data(ttl=90, show_spinner=False)
def spot():
    if ak is None:
        raise RuntimeError("AKShare 未安装")
    x = ak.stock_zh_a_spot_em().copy()
    x["代码"] = x["代码"].astype(str).str.zfill(6)
    for c in ["最新价","涨跌幅","成交额","换手率","量比"]:
        if c in x:
            x[c] = n(x[c])
    return x

@st.cache_data(ttl=1200, show_spinner=False)
def hist(code):
    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now()-timedelta(days=150)).strftime("%Y%m%d")
    try:
        x = ak.stock_zh_a_hist(symbol=code, period="daily",
                               start_date=start, end_date=end, adjust="qfq")
        for c in ["开盘","收盘","最高","最低","成交量","成交额","换手率","涨跌幅"]:
            if c in x: x[c] = n(x[c])
        return x.tail(70).reset_index(drop=True)
    except Exception:
        return pd.DataFrame()

@st.cache_data(ttl=300, show_spinner=False)
def fund(code):
    try:
        market = "sh" if code.startswith("6") else "sz"
        return ak.stock_individual_fund_flow(stock=code, market=market)
    except Exception:
        return pd.DataFrame()

def hist_score(h):
    if len(h) < 20:
        return dict(trend=50, volume=50, position=50, trigger=np.nan, support=np.nan)
    c=h["收盘"]; v=h["成交量"]
    ma5=c.rolling(5).mean(); ma10=c.rolling(10).mean(); ma20=c.rolling(20).mean()
    trend=50
    trend += 15 if c.iloc[-1] > ma5.iloc[-1] else -8
    trend += 12 if ma5.iloc[-1] > ma10.iloc[-1] else -6
    trend += 10 if ma10.iloc[-1] > ma20.iloc[-1] else -5
    vr=v.iloc[-1]/max(v.tail(6).iloc[:-1].mean(),1)
    volume=np.clip(45+(vr-1)*35,0,100)
    hi=c.tail(20).max(); lo=c.tail(20).min()
    p=(c.iloc[-1]-lo)/max(hi-lo,1e-9)
    position=np.clip(100-abs(p-.55)*120,0,100)
    trigger=max(h["最高"].tail(3).iloc[:-1].max(), ma5.iloc[-1])
    support=min(h["最低"].tail(5).min(), ma10.iloc[-1])
    return dict(trend=float(np.clip(trend,0,100)), volume=float(volume),
                position=float(position), trigger=float(trigger), support=float(support))

def fund_score(ff):
    if ff is None or ff.empty:
        return 50, "资金数据不足"
    cols=[c for c in ff.columns if "主力净流入" in str(c) and "净占比" not in str(c)]
    if not cols:
        return 50, "资金字段未识别"
    s=n(ff[cols[0]]).dropna().tail(5)
    if s.empty:
        return 50, "资金数据不足"
    score=50 + (12 if s.iloc[-1] > 0 else -10)
    if len(s)>=2 and (s.tail(2)>0).all(): score+=12
    if len(s)>=3 and (s.tail(3)>0).sum()>=2: score+=8
    return float(np.clip(score,0,100)), f"近3日净流入 {int((s.tail(3)>0).sum())}/3"

def market_env(x):
    pct=n(x["涨跌幅"]).dropna()
    if pct.empty: return 50,0,0
    up=(pct>0).mean()*100
    med=float(pct.median())
    score=np.clip(45+(up-50)*.8+med*5,0,100)
    return round(float(score)),round(float(up),1),round(med,2)

def prefilter(x,cfg):
    y=x.copy()
    y=y[y.apply(lambda r: allowed(r["代码"], r["名称"]),axis=1)]
    y=y[(y["最新价"]>=cfg["min_price"])&(y["最新价"]<=cfg["max_price"])]
    y=y[y["成交额"]>=cfg["min_turnover_yi"]*1e8]
    y=y[y["换手率"]>=cfg["min_turnover_rate"]]
    y=y[(y["涨跌幅"]<=cfg["max_day_pct"])&(y["涨跌幅"]>=-7.5)]
    liq=y["成交额"].rank(pct=True)*35
    turn=y["换手率"].rank(pct=True)*25
    vr=y["量比"].fillna(1).clip(0,3).rank(pct=True)*20
    chase=(1-(y["涨跌幅"].abs()/10).clip(0,1))*20
    y["预筛分"]=liq+turn+vr+chase
    return y.sort_values("预筛分",ascending=False).head(cfg["max_candidates"])

def deep(pre,cfg):
    rows=[]
    bar=st.progress(0,text="读取候选股历史数据与资金流…")
    total=max(len(pre),1)
    for i,(_,r) in enumerate(pre.iterrows()):
        code=r["代码"]; h=hist(code); hs=hist_score(h); fs,ft=fund_score(fund(code))
        liquidity=min(100,45+np.log10(max(r["成交额"],1)/1e8+1)*25+min(r["换手率"],12)*2)
        chase=max(0,min(100,100-max(r["涨跌幅"],0)*12))
        score=fs*.28+hs["trend"]*.22+hs["volume"]*.15+hs["position"]*.15+liquidity*.10+chase*.10
        price=float(r["最新价"])
        trig=hs["trigger"] if pd.notna(hs["trigger"]) else price*1.01
        trig=min(max(trig,price*.998),price*1.035)
        stop=min(trig*(1-cfg["stop_loss_pct"]/100),
                 hs["support"] if pd.notna(hs["support"]) else trig*(1-cfg["stop_loss_pct"]/100))
        status="可买触发" if score>=82 and price>=trig*.995 else ("重点观察" if score>=72 else "放弃")
        rows.append({
            "代码":code,"名称":r["名称"],"现价":round(price,2),"涨跌幅":round(r["涨跌幅"],2),
            "成交额(亿)":round(r["成交额"]/1e8,2),"换手率":round(r["换手率"],2),
            "综合分":round(score,1),"资金分":round(fs,0),"趋势分":round(hs["trend"],0),
            "量价分":round(hs["volume"],0),"位置分":round(hs["position"],0),
            "资金说明":ft,"触发价":round(trig,2),"止损":round(stop,2),
            "止盈1":round(trig*(1+cfg["take_profit1_pct"]/100),2),
            "止盈2":round(trig*(1+cfg["take_profit2_pct"]/100),2),"状态":status
        })
        bar.progress((i+1)/total,text=f"{i+1}/{total} {r['名称']}")
    bar.empty()
    return pd.DataFrame(rows).sort_values("综合分",ascending=False)

st.title("🎯 短线狙击工作台")
st.caption("1～5个交易日｜少做、快出｜公开行情 V1")

with st.sidebar:
    st.header("筛选")
    minp=st.number_input("最低股价",1.0,100.0,5.0,1.0)
    maxp=st.number_input("最高股价",5.0,200.0,30.0,1.0)
    minamt=st.number_input("最低成交额（亿元）",1.0,100.0,5.0,1.0)
    minturn=st.number_input("最低换手率（%）",0.0,30.0,1.0,.5)
    maxpct=st.number_input("最大当日涨幅（%）",1.0,10.0,5.0,.5)
    count=st.slider("深度分析候选数",10,60,35,5)
    st.caption("排除科创板 / 创业板 / 北交所 / ST / 退市股")

cfg=DEFAULT.copy()
cfg.update(min_price=minp,max_price=maxp,min_turnover_yi=minamt,
           min_turnover_rate=minturn,max_day_pct=maxpct,max_candidates=count)

a,b=st.columns(2)
run=a.button("🚀 扫描全A股",type="primary",use_container_width=True)
refresh=b.button("清空缓存",use_container_width=True)
if refresh:
    st.cache_data.clear()
    st.rerun()

if run:
    try:
        with st.spinner("读取全市场行情…"):
            x=spot()
        st.session_state.env=market_env(x)
        st.session_state.result=deep(prefilter(x,cfg),cfg)
    except Exception as e:
        st.error(f"数据读取失败：{e}")
        st.info("检查服务器是否能正常访问互联网；稍后重试也可能恢复。")

if "env" in st.session_state:
    ms,up,med=st.session_state.env
    c1,c2,c3=st.columns(3)
    c1.metric("市场环境",f"{ms}/100");c2.metric("上涨占比",f"{up}%");c3.metric("涨跌中位",f"{med}%")
    if ms<45: st.warning("环境偏弱：宁可空仓。")
    elif ms<65: st.info("环境一般：只做高分确认型机会。")
    else: st.success("环境较友好：仍不追高，严格止损。")

if "result" in st.session_state:
    result=st.session_state.result
    top=result[result["状态"]!="放弃"].head(3)
    st.subheader(f"今日机会：{len(top)}只")
    if top.empty:
        st.warning("没有达到阈值的机会：空仓 / 继续观察。")
    else:
        for _,r in top.iterrows():
            with st.container(border=True):
                c1,c2,c3,c4=st.columns([1.2,.7,1,1])
                c1.markdown(f"### {r['名称']} `{r['代码']}`\n现价 **{r['现价']}** ｜ {r['涨跌幅']:+.2f}%")
                c2.metric("综合分",r["综合分"])
                c3.markdown(f"**触发 {r['触发价']}**  \n止损 {r['止损']}  \n目标1 {r['止盈1']}")
                c4.markdown(f"**{r['状态']}**  \n{r['资金说明']}  \n目标2 {r['止盈2']}")
    st.subheader("候选池")
    st.dataframe(result,use_container_width=True,hide_index=True)
    st.download_button("下载 CSV",result.to_csv(index=False).encode("utf-8-sig"),
                       f"短线筛选_{datetime.now():%Y%m%d_%H%M}.csv","text/csv")

st.divider()
st.caption("V1 是筛选与纪律工具，不是收益预测器。“主力资金”是数据商算法指标，不代表真实机构身份。")
